-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: moneymoa
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chatroomdto`
--

DROP TABLE IF EXISTS `chatroomdto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatroomdto` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `imgUrl` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `roomId` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatroomdto`
--

LOCK TABLES `chatroomdto` WRITE;
/*!40000 ALTER TABLE `chatroomdto` DISABLE KEYS */;
INSERT INTO `chatroomdto` VALUES (4,NULL,NULL,'싸피방','2595c66d-e991-4976-b980-9c47710885ea'),(5,NULL,NULL,'개발자 방','4c815f89-84e6-44dd-860b-c24a737ec8e1'),(6,NULL,NULL,'헬로우 ','349055a4-5a8d-4fa2-bab8-cdbfdc3d9e89'),(7,NULL,NULL,'테스트방','ef3892f2-437a-4005-9d90-7466582bbbc1'),(8,NULL,NULL,'엄랭 개발자 방','8770e7c3-6350-41b8-9c28-f77b4f8e4347'),(9,NULL,NULL,'구미 싸피','ef2e36b3-935e-4da6-952a-cb9b935c35e7'),(10,NULL,NULL,'싸피 조아','86b7a2e3-1c28-4307-be1b-4af4d22ccb36'),(11,NULL,NULL,'싸피 조아','c3a5a45e-944b-4bf5-a2dd-cdb2cd452121'),(12,NULL,NULL,'싸피 조아2','6e4ce3cb-c6ec-4e41-8e08-051aeec71bfb'),(13,NULL,NULL,'싸피 조아3','a4ef3ccf-2b97-4edf-8b48-01aa135ac00a'),(14,NULL,NULL,'싸피 조아','69200e27-a00d-412e-9425-858dbb5480be'),(15,NULL,NULL,'싸피 모여라','48901993-1f93-4c6a-b95c-ff53febf16b9'),(16,NULL,NULL,'구미 싸피 모여라','aaf678cb-39e9-43e0-be22-328cd2aaefc9'),(17,NULL,NULL,'하이','8f929a86-7008-482f-a538-dc7e6390c55c');
/*!40000 ALTER TABLE `chatroomdto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 17:07:59
