-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: moneymoa
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chatmessagedto`
--

DROP TABLE IF EXISTS `chatmessagedto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatmessagedto` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `message` varchar(255) DEFAULT NULL,
  `roomId` varchar(255) DEFAULT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatmessagedto`
--

LOCK TABLES `chatmessagedto` WRITE;
/*!40000 ALTER TABLE `chatmessagedto` DISABLE KEYS */;
INSERT INTO `chatmessagedto` VALUES (1,'엄','ae0ad56f-06a4-488f-a567-f118b62675c5','엄랭 개발자','TALK'),(2,'준','ae0ad56f-06a4-488f-a567-f118b62675c5','엄랭 개발자','TALK'),(3,'식','ae0ad56f-06a4-488f-a567-f118b62675c5','엄랭 개발자','TALK'),(4,'랄로님이 입장하셨습니다.','ae0ad56f-06a4-488f-a567-f118b62675c5','랄로','ENTER'),(5,'엄','ae0ad56f-06a4-488f-a567-f118b62675c5','랄로','TALK'),(6,'준','ae0ad56f-06a4-488f-a567-f118b62675c5','랄로','TALK'),(7,'식','ae0ad56f-06a4-488f-a567-f118b62675c5','랄로','TALK'),(8,'구미베어님이 입장하셨습니다.','60445573-baa0-432f-b5a8-dcfc8ee8ad55','구미베어','ENTER'),(9,'하이 나는 구미베어','60445573-baa0-432f-b5a8-dcfc8ee8ad55','구미베어','TALK'),(10,'null님이 입장하셨습니다.','60445573-baa0-432f-b5a8-dcfc8ee8ad55','null','ENTER'),(11,'김싸피님이 입장하셨습니다.','60445573-baa0-432f-b5a8-dcfc8ee8ad55','김싸피','ENTER'),(12,'하이요','60445573-baa0-432f-b5a8-dcfc8ee8ad55','김싸피','TALK'),(13,'MoneyMoa 관리자님이 입장하셨습니다.','389e3fd7-1c74-4af8-9ec6-079113bb5820','MoneyMoa 관리자','ENTER'),(14,'반갑다 얘들아','389e3fd7-1c74-4af8-9ec6-079113bb5820','MoneyMoa 관리자','TALK'),(15,'MoneyMoa 관리자님이 입장하셨습니다.','1828043d-85d2-455d-addf-7636ea0ca4c2','MoneyMoa 관리자','ENTER'),(16,'안녕 얘들아','1828043d-85d2-455d-addf-7636ea0ca4c2','MoneyMoa 관리자','TALK'),(17,'안녕 얘들아','555887d3-4ba3-4f6d-802e-9b47e9404f59','MoneyMoa 관리자','TALK'),(18,'김싸피님이 입장하셨습니다.','555887d3-4ba3-4f6d-802e-9b47e9404f59','김싸피','ENTER'),(19,'정싸피님이 입장하셨습니다.','755650cd-6976-44b0-92cf-45ae51eec672','정싸피','ENTER'),(20,'하이요','755650cd-6976-44b0-92cf-45ae51eec672','정싸피','TALK'),(21,'나는 정싸피','755650cd-6976-44b0-92cf-45ae51eec672','정싸피','TALK'),(22,'정싸피님이 입장하셨습니다.','755650cd-6976-44b0-92cf-45ae51eec672','정싸피','ENTER');
/*!40000 ALTER TABLE `chatmessagedto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 17:07:58
