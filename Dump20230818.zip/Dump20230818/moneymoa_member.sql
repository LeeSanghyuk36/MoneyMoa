-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: moneymoa
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `oAuthProvider` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `valid` int NOT NULL,
  `birthday` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `imageUrl` varchar(255) DEFAULT NULL,
  `introduce` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (15,'MoneyMoa','MoneyMoa 관리자','MoneyMoa 관리자','GENERAL','admin','ADMIN',1,'000000','관리자',NULL,NULL,NULL),(16,'wjddnjsrbs97@gmail.com','정원균','원균짱','GENERAL','1234','MEMBER',1,'2021.04.11','남자',NULL,NULL,NULL),(17,'wjddnjsrbs97@naver.com','정원균','정원균','KAKAO','SNS LOGIN','MEMBER',1,NULL,NULL,NULL,NULL,NULL),(20,'abcd@naver.com','이싸피','싸피몬스터','GENERAL','1234','MEMBER',1,'2012.12.11','여',NULL,NULL,NULL),(21,'wjddnjsrbs97@naver.co.kr',NULL,NULL,'NAVER','SNS LOGIN','MEMBER',1,NULL,NULL,NULL,NULL,NULL),(22,'um','엄준식','엄준식은 살아있다','GENERAL','$2a$10$r3QztjH9x1yiuy4FBXZkWesjoxkIAMMbIbJcifOHIsYmz/NfyIbIu','MEMBER',1,'string','string',NULL,NULL,NULL),(23,'umum','string','string','GENERAL','1234','MEMBER',1,'string','string',NULL,NULL,NULL),(24,'umumum','하이하이','엄준식123','GENERAL','$2a$10$q7CxZUTpONT41fK9TN/c2Oam4jdrwS8g801ASyVkQz2Gku6VGzApK','MEMBER',1,'string','string','https://moneymoa-first-bucket.s3.ap-northeast-2.amazonaws.com/1692112637096%20%ED%99%94%EB%A9%B4%20%EC%BA%A1%EC%B2%98%202023-08-04%20123512.png','엄준식은 살아있습니',NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 17:07:58
