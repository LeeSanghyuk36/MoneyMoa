-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: moneymoa
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `feed`
--

DROP TABLE IF EXISTS `feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feed` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `challenge` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `createDateTime` datetime(6) DEFAULT NULL,
  `depositAmount` int DEFAULT NULL,
  `hashtag` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `member_id` bigint DEFAULT NULL,
  `feedLikeCount` int DEFAULT '0',
  `memberId` bigint DEFAULT NULL,
  `challengeId` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3yx75sj6wanid7jasyb4cneag` (`member_id`),
  KEY `FKqdl6hcpqukcbjh4xrp1j2bhbm` (`challengeId`),
  KEY `FKclu0xf7u3vbiiq4cvgkx0rrl1` (`memberId`),
  CONSTRAINT `FK3yx75sj6wanid7jasyb4cneag` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FKclu0xf7u3vbiiq4cvgkx0rrl1` FOREIGN KEY (`memberId`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feed`
--

LOCK TABLES `feed` WRITE;
/*!40000 ALTER TABLE `feed` DISABLE KEYS */;
INSERT INTO `feed` VALUES (1,NULL,'피드작성테스트','2023-08-13 15:09:10.990846',123,'#테스트','string',NULL,0,23,1),(2,NULL,'피드작성테스트','2023-08-13 15:32:18.235381',123,'#테스트','string',NULL,0,23,1),(3,NULL,'피드작성테스트','2023-08-13 15:45:03.487837',123,'#테스트','string',NULL,0,23,1),(4,NULL,'피드작성테스트','2023-08-13 15:46:11.172794',123,'#테스트','string',NULL,0,23,1),(5,NULL,'피드작성테스트','2023-08-13 15:49:50.759368',123,'#테스트','string',NULL,0,23,1),(6,NULL,'피드작성테스트','2023-08-13 15:54:38.406208',123,'#테스트','string',NULL,0,23,1),(7,NULL,'피드작성테스트','2023-08-13 16:12:27.557247',123,'#테스트','string',NULL,0,23,1),(8,NULL,'피드작성테스트','2023-08-13 16:17:09.686468',123,'#테스트','string',NULL,0,23,1),(9,NULL,'피드작성테스트','2023-08-13 16:21:02.169659',123,'#테스트','string',NULL,0,23,1),(10,NULL,'피드작성테스트','2023-08-13 16:24:04.868625',123,'#테스트','string',NULL,0,23,1),(11,NULL,'피드작성테스트','2023-08-13 16:27:33.592338',123,'#테스트','string',NULL,0,23,1),(12,NULL,'피드작성테스트','2023-08-13 16:33:44.196013',123,'#테스트','string',NULL,0,23,1),(13,NULL,'피드작성테스트','2023-08-13 16:41:33.550775',123,'#테스트','string',NULL,0,23,1),(14,NULL,'피드작성테스트','2023-08-13 16:44:20.800659',123,'#테스트','string',NULL,0,23,1),(15,NULL,'피드작성테스트','2023-08-13 16:45:09.838313',123,'#테스트','string',NULL,0,23,1),(16,NULL,'피드작성테스트','2023-08-13 16:46:13.179832',123,'#테스트','string',NULL,0,23,1),(17,NULL,'피드작성테스트','2023-08-13 16:54:53.358708',123,'#테스트','string',NULL,0,23,1),(18,NULL,'피드작성테스트','2023-08-13 16:58:07.219543',123,'#테스트','string',NULL,0,23,1),(19,NULL,'피드작성테스트','2023-08-13 17:01:35.535449',123,'#테스트','string',NULL,0,23,1),(20,NULL,'피드작성테스트','2023-08-13 17:08:19.104784',123,'#테스트','string',NULL,0,23,1),(21,NULL,'피드작성테스트','2023-08-13 17:09:48.758028',123,'#테스트','string',NULL,0,23,1),(22,NULL,'피드작성테스트','2023-08-13 17:12:41.041534',123,'#테스트','string',NULL,0,23,1),(23,NULL,'피드작성테스트','2023-08-13 17:16:50.057560',123,'#테스트','string',NULL,0,23,1),(24,NULL,'피드작성테스트','2023-08-13 17:19:42.904500',123,'#테스트','string',NULL,0,23,1),(25,NULL,'피드작성테스트','2023-08-13 17:22:00.339939',123,'#테스트','string',NULL,0,23,1),(26,NULL,'피드작성테스트','2023-08-13 17:22:25.079520',123,'#테스트','string',NULL,0,23,1);
/*!40000 ALTER TABLE `feed` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-18 17:07:58
